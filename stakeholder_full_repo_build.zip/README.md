
# Stakeholder Hub

Repository contains:

backend/
API server

frontend/
Next.js platform

frontend/admin/
platform control panel

infrastructure/
docker + terraform

Run backend:
cd backend
npm install
npm run dev

Run frontend:
cd frontend
npm install
npm run dev
