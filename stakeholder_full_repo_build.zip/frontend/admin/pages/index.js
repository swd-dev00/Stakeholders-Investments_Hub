
import {useState} from 'react'

export default function Admin(){

 const [systems,setSystems] = useState({
  trust:true,
  ai:true,
  momentum:true,
  investorMatching:true
 })

 function toggle(name){
  setSystems({...systems,[name]:!systems[name]})
 }

 return (
  <div style={{padding:40}}>
   <h1>Platform Control Panel</h1>

   {Object.keys(systems).map(system=>(
     <div key={system} style={{marginBottom:10}}>
       <b>{system}</b>
       <button onClick={()=>toggle(system)} style={{marginLeft:10}}>
        {systems[system] ? "ON":"OFF"}
       </button>
     </div>
   ))}

  </div>
 )
}
