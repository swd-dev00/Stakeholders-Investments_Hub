
export default function VentureCard({venture}){
 return (
  <div style={{border:'1px solid #ddd',padding:10,marginBottom:10}}>
   <h3>{venture.title}</h3>
   <p>{venture.sector}</p>
  </div>
 )
}
