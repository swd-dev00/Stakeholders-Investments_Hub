
export default function Home(){
 return (
  <div style={{padding:40}}>
   <h1>Stakeholder Hub</h1>
   <p>Venture Intelligence Platform</p>
  </div>
 )
}
