
export default function Dashboard(){
 return (
  <div style={{padding:40}}>
   <h2>Investor Dashboard</h2>
   <p>Recommended ventures appear here.</p>
  </div>
 )
}
