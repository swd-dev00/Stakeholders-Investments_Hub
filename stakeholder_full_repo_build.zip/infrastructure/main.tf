
# placeholder terraform infra
provider "google" {
 project = "stakeholder-hub"
 region  = "us-central1"
}
