
import express from 'express'
import { v4 as uuidv4 } from 'uuid'

const app = express()
app.use(express.json())

let ventures:any[] = []

app.get('/health',(req,res)=>{
 res.json({status:'ok'})
})

app.post('/ventures',(req,res)=>{

 const venture = {
  ventureId:"venture_"+uuidv4(),
  title:req.body.title,
  sector:req.body.sector,
  stage:req.body.stage,
  createdAt:Date.now()
 }

 ventures.push(venture)

 res.json(venture)

})

app.get('/ventures',(req,res)=>{
 res.json(ventures)
})

app.listen(4000,()=>{
 console.log("Stakeholder Hub API running on 4000")
})
